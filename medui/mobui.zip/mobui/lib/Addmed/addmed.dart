import 'package:flutter/material.dart';
import 'package:pharmaui/Widget/KendilAppBar.dart';

void main() {
  runApp(MaterialApp(home: AddMedicineScreen()));
}

class AddMedicineScreen extends StatefulWidget {
  @override
  _AddMedicineScreenState createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _descriptionController = TextEditingController();
  TextEditingController _priceController = TextEditingController();
  TextEditingController _quantityController = TextEditingController();

  String _selectedImage = '';

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  void _selectImage() {
    // Implement image selection logic here
  }

  // void _addMedicine() {
  //   String name = _nameController.text;
  //   String description = _descriptionController.text;
  //   double price = double.parse(_priceController.text);
  //   int quantity = int.parse(_quantityController.text);
  //   String image = _selectedImage;

    // Implement logic to add the medicine (e.g., save to a database)

  //   // Clear the input fields
  //   _nameController.clear();
  //   _descriptionController.clear();
  //   _priceController.clear();
  //   _quantityController.clear();
  //   setState(() {
  //     _selectedImage = '';
  //   });

  //   // Show a confirmation dialog or navigate to a success screen
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: Text('Medicine Added'),
  //         content: Text('The medicine has been successfully added.'),
  //         actions: [
  //           TextButton(
  //             onPressed: () {
  //               Navigator.pop(context);
  //             },
  //             child: Text('OK'),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:KendilAppBar(title: Text('Add Medicine'),),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            SizedBox(height: 16.0),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
              maxLines: 3,
            ),
            SizedBox(height: 16.0),
            TextFormField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            TextFormField(
              controller: _quantityController,
              decoration: InputDecoration(labelText: 'Type'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            TextFormField(
              controller: _quantityController,
              decoration: InputDecoration(labelText: 'Manufacturer'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            Container(
              height: 200.0,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: (_selectedImage.isNotEmpty)
                  ? Image.network(
                      _selectedImage,
                      fit: BoxFit.cover,
                    )
                  : IconButton(
                      icon: Icon(Icons.camera_alt),
                      onPressed: _selectImage,
                    ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
                onPressed: () {},
                child: Text(
                  'Add Medicine',
                  style: TextStyle(color: Colors.lightGreen),
                ),
                style: ButtonStyle(
                  side: MaterialStateProperty.all(
                    BorderSide(color: Colors.lightGreen, width: 2),
                  ),
                ),
                ),
          ],
        ),
      ),
    );
  }
}